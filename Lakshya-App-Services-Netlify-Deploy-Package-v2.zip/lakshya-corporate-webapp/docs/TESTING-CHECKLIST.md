# QA checklist

## Navigation and interaction
- [ ] Every top navigation item scrolls to its matching section.
- [ ] Mobile menu opens, closes and updates its accessible expanded state.
- [ ] Each product card opens the correct detail modal.
- [ ] Product modal closes with close button, backdrop and Escape key.
- [ ] “Discuss this product” closes the modal and scrolls to the enquiry form.
- [ ] Presentation mode opens and Previous / Next / Exit work.
- [ ] Print / Save as PDF opens the browser print dialog.
- [ ] Company summary download creates a text file.
- [ ] Enquiry form validates required fields and opens a prefilled email draft.

## Layout and accessibility
- [ ] Test at 360px, 390px, tablet and desktop widths.
- [ ] Confirm no horizontal overflow on mobile.
- [ ] Check keyboard navigation and visible focus.
- [ ] Check images load and alternative text is appropriate.
- [ ] Check reduced-motion preference.
- [ ] Review print/PDF output.

## Content and launch readiness
- [ ] Confirm legal business identity and proprietor details before adding them.
- [ ] Verify each product's launch status and add real links only.
- [ ] Add only authorised, current certificates and documents.
- [ ] Confirm public contact information is correct.
- [ ] Add a privacy policy and backend configuration before collecting form submissions on a server.
- [ ] Verify that the new site is separate and the existing site remains unchanged.
