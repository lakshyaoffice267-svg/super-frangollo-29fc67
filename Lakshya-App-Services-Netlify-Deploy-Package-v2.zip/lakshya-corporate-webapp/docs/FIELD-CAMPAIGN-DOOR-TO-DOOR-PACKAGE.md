# LAKSHYA APP SERVICES — Field Campaign & Door-to-Door Outreach Package

## Purpose
A configurable campaign service for schools, colleges, coaching centres, hospitals, local businesses, community organisations and other approved audiences. This is a proposed package framework; it does not assert that field staff are currently deployed or that visits/results have already occurred.

## Package modules
1. **Discovery & campaign brief:** objective, audience, offer/service, campaign dates, locations, expected outcomes, client approvals and constraints.
2. **Audience and territory mapping:** prospect categories, district/ward/locality lists, prioritisation, route clusters and appointment requirements.
3. **Visit plan:** daily schedule, visit windows, travel assumptions, backup plan, team allocation and supervisor contact.
4. **Door-to-door outreach:** approved introduction script, short pitch, brochure/leaflet, QR link, enquiry form, respectful refusal/opt-out recording and no-pressure conduct.
5. **Institution visits:** appointment-first approach where practical, meeting with authorised decision-makers, needs discovery, approved product/service demonstration and next-step agreement.
6. **Campaign collateral:** brochure, pitch deck, FAQ, visiting card/ID format, consent notice, QR landing page and regional-language adaptation where scoped. Client must approve claims, logos, offers and printed/digital materials before use.
7. **Lead and enquiry capture:** organisation name/type, locality, date, contact person's role, business contact details only where appropriate, permission/consent status, interest, lead temperature, notes and follow-up date. Avoid collecting unnecessary personal or sensitive information.
8. **Follow-up operations:** call/message schedule, appointment booking, demo coordination, proposal requests, revisit reminders, opt-out and do-not-contact handling.
9. **Field-team operations:** role allocation, training, attendance, daily briefing/debrief, authorised ID, safety check-in, travel logs, expense evidence and escalation process.
10. **Quality control:** supervisor review of visit logs, duplicate checking, sample call-backs only with permission, material/claim compliance and correction of inaccurate records.
11. **Reporting dashboard:** planned vs completed visits, unique organisations reached, authorised decision-makers met, interested leads, appointments, demonstrations, proposals, conversions (if verified), follow-ups due, refusals/opt-outs and reasons for no interest.
12. **Close-out & recommendations:** summary report, lead handover, outstanding follow-up list, expense summary against agreed policy, lessons learned and next-phase recommendation.

## Suggested deliverables
- Campaign brief and approved messaging
- Area/route plan and visit calendar
- Field checklist and visit register
- Approved brochure/presentation/QR enquiry path (where included)
- Lead tracker with status and next action
- Daily/weekly progress summary
- Final campaign report and handover meeting

## Recommended workflow
**Enquiry → Discovery → Scope & quotation → Written approval/agreement → Material approval → Team briefing → Field visits → Daily review → Follow-ups → Final report → Handover.**

## Scope and commercial controls
Every proposal should explicitly define: campaign duration; covered geography; team size and working hours; target audience; visit and qualified-lead definitions; expected activity levels (not guaranteed sales); travel, accommodation, printing, phone/data and event costs; taxes if applicable; client-provided assets/access; reporting frequency; approval deadlines; data ownership/access/retention; cancellation, postponement and change requests; exclusions; payment schedule; and who signs off deliverables. Public website does not show internal price options. A quote is prepared only after the brief is approved.

## Compliance and safety checklist
- Obtain permission for venue entry, appointments, photography, recordings and use of logos where required.
- Identify representatives truthfully and carry valid authorisation/ID as applicable.
- Do not promise guaranteed sales, outcomes, certifications or product features without evidence.
- Respect school/institution policies, working hours, local rules and personal boundaries.
- Record consent/permission and honour opt-outs promptly.
- Limit access to lead data; use approved storage; define retention and deletion.
- Use a buddy/check-in process for field staff and a clear escalation contact.

## KPIs (report actuals separately from targets)
- Visits planned / completed
- Unique organisations reached
- Decision-makers met
- Interested leads by HOT / WARM / INFO (definitions agreed in advance)
- Appointments and demonstrations booked/completed
- Proposals requested/sent
- Follow-ups due/completed
- Opt-outs / not-interested outcomes
- Cost per completed visit or qualified lead, only when costs and definitions are reliable
- Conversions, only when independently supported by CRM/agreement records

## Not included unless written into scope
Paid advertising budget, printing/shipping, travel and accommodation, venue rental, incentives, event production, call-centre staffing, custom software development, CRM subscriptions, legal advice, guaranteed lead volume, guaranteed conversions or any unapproved claims.

## Internal agreement-wise accounting (private operations only)
For each signed agreement, maintain a unique agreement ID, client, approved scope/version, agreement date, total agreed value, tax treatment reviewed by the responsible professional, invoice number/date, milestone due date, amount due/received, payment reference, balance, expense category, approval, supporting receipt, change orders, overdue status and reconciliation notes. Restrict this register to authorised staff; do not publish client-specific amounts or internal package options on the public profile. The actual payment schedule must be written into each signed agreement and must not be assumed from a generic template.
