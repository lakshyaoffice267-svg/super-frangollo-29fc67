# Company Details Register — Lakshya App Services

This register captures details supplied by the business owner. Verify each item against the original record before making legal claims or publishing a scan.

| Field | Supplied value | Verification / publication note |
|---|---|---|
| Business name | LAKSHYA APP SERVICES | Match spelling to registration and invoice records |
| Business form | Proprietorship | Confirm using the relevant original record |
| Location | Guwahati, Assam, India | Confirm full registered/business address if needed |
| Website | https://lakshyaapp.in/ | Confirm current ownership and functioning links |
| Email | support@lakshyaapp.in | Send a test email before launch |
| Phone | +91 6000814103 | Confirm it is the intended public business contact |
| Proprietor | Pinky Roy | Confirm against original registration document |
| Establishment year | 2024 | Based on business records supplied; verify documentary basis |
| Udyam reference | UDYAM-AS-03-0080835 | Match against original certificate and current status |
| Trade licence reference | 1780294253963640 | Match against licence copy, issuing authority and validity |
| UBN reference | 618/724739/BJTPR4029P/2/2026 | Match against original document and identify issuing authority |

## Three-year institutional outreach plan
- Year 1: 2,500 cumulative institutions (25% of the 10,000 target)
- Year 2: 6,000 cumulative institutions (60% cumulative target)
- Year 3: 10,000 cumulative institutions (100% cumulative target)

These are planning targets, not completed outreach, signed partners, active customers or guaranteed outcomes. A CRM should separately track planned, contacted, meeting held, proposal issued, agreement signed and active institution.

## Additional information to collect for a final profile
- Full registered address, business hours and public support channel
- Clear description of each product's current status and verified app/store URLs
- Approved founder/proprietor biography and team roles
- Real project case studies with permission to publish names/logos
- Certificate scans or verification records for registrations, with unnecessary personal data redacted
- Approved privacy policy, terms, grievance/support contact and data-handling process
- Approved photos, screenshots, brand assets and social media URLs
- Actual project references, awards or certifications only when documentary evidence exists
