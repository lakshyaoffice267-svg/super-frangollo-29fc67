# Corporate Profile Content and Gap Register

## Included in this package
- Corporate profile and brand presentation
- Vision, mission and values
- Product showcase and feature concepts
- Services, technology, project demonstrations and partnerships
- Department responsibility framework (not a claim of staffed departments)
- Company details supplied by the owner, with verification notes
- Three-year Assam institutional outreach target (explicitly labelled as projection)
- Public contact details supplied by the owner
- Print-friendly browser PDF option and downloadable text summary
- Internal-only agreement-wise commercial configuration guide
- Deployment and testing checklists

## Pending owner confirmation / evidence
1. Registration identifiers, proprietor spelling, legal form and establishment year against originals.
2. Full business address and approved public contact details.
3. Product live/demo/planned status and verified links.
4. Actual staffing, department ownership and leadership biographies.
5. Actual project portfolio, customer references, institution relationships, awards and testimonials.
6. Final approved Privacy Policy, Terms, complaint/grievance channel and data retention process.
7. Any public certificate display permission; redact private fields from uploaded scans.
8. Backend requirements for CRM, lead capture, accounts, HR, admin, reports and agreement/payment tracking.

## Implementation truth
The included webapp is a static frontend. It does not currently provide authentication, database storage, real CRM/accounting, payment collection, live app integration, or server-side form submission. These need separate backend design, implementation, security review and testing.

The confidential agreement-wise commercial configuration guide is packaged in a sibling `OWNER-PRIVATE` folder outside the publishable website folder. Do not copy it into the website directory.
