# Netlify deployment guide

1. Download and extract the ZIP on your computer.
2. Open Netlify and create a **new** site. Do not select or overwrite the existing site.
3. Deploy the extracted `lakshya-corporate-webapp` folder contents. This is a static website: no build command is required and the publish directory is `.`.
4. Open the new URL and complete the testing checklist in `TESTING-CHECKLIST.md`.
5. Only after successful testing, add a link to the new site from the main `lakshyaapp.in` website.
6. If you later add a backend, configure HTTPS, spam protection, access permissions, privacy notice and data retention before collecting personal information.


## Before public launch
- Confirm business name, proprietor, establishment year, Udyam, trade licence and UBN against original records.
- Confirm that `support@lakshyaapp.in` and `+91 6000814103` are approved public contacts.
- The file `internal/INTERNAL-COMMERCIAL-CONFIGURATION.md` contains confidential package and milestone planning; do not upload it to any public-facing document library. It is included in the ZIP for owner/internal use only. If uploading the entire folder to a public repository, move that file to a private location first.
- Public-facing website files include only the projection targets, not the internal package values.

**Important:** In the ZIP, deploy only the `lakshya-corporate-webapp` folder. The sibling `OWNER-PRIVATE` folder is for the business owner only and must never be deployed or added to a public repository.
