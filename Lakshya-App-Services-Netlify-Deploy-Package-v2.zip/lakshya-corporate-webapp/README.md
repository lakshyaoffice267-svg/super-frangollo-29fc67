# Lakshya App Services — Corporate WebApp

A responsive, English-language corporate profile and product showcase built as a standalone static website for a separate Netlify project. It does not modify the existing Lakshya website or existing Netlify site.

## Features
- Company identity and supplied registration references with explicit verification notes
- Three-year Assam institutional outreach projection: 2,500 / 6,000 / 10,000 cumulative targets, clearly not actuals
- Department responsibility framework for company planning
- Company details register, content-gap register and confidential internal commercial configuration guide
- Responsive desktop and mobile layout with collapsible mobile navigation
- Sticky navigation with active-section highlighting and smooth scrolling
- Product cards for Lakshya A to Z Solutions, Worker, Partner, Vendor, Education ERP, Advertisement and Hello Doctor
- Product-detail modal pages with features, intended users, status and clear caveats
- Animated hero, floating cards, campaign visual, technology diagram and hover states
- Presentation mode with previous/next section controls
- Print / Save as PDF using the browser print dialog
- Downloadable plain-text company summary
- Business enquiry form that opens the visitor's email app (no server transmission)
- Accessibility basics: semantic sections, keyboard product cards, focus styles, reduced-motion support
- Netlify-ready static file structure

## Run locally
Open `index.html` in a modern browser. For a local HTTP server, run from this directory:

```bash
python -m http.server 8080
```

Then open `http://localhost:8080`.

## Deploy to a NEW Netlify site
1. Keep your existing website and Netlify project unchanged.
2. Sign in to Netlify and create a separate new site/project.
3. Upload/deploy this project's folder contents (or connect a Git repository containing them).
4. No build command is required. Publish directory is the project root (`.`).
5. Test the generated Netlify URL on desktop and mobile before linking it from `lakshyaapp.in`.

## Important production notes
- This is a static front-end. The enquiry form opens a pre-filled email draft; it does not submit to a database or CRM.
- Demo interactions run in the browser. A production enquiry/lead database requires a separately configured backend or form service, privacy notice, access controls and retention policy.
- Replace product links with verified working URLs when available. Do not describe an app as published/live without verification.
- Add real legal registration details, certificates, launch dates, team details, client references and achievements only after checking supporting records.
- The provided product logos and two screenshots are included as user-supplied assets. The screenshots are labelled as references to the previous presentation layout.
- No financial performance, verified customer count, institutional endorsement, guaranteed campaign result, medical service or legal compliance certification is claimed. Registration identifiers and proprietor details are owner-supplied and marked for original-document verification. The internal commercial configuration file is confidential and must not be published.

## Main files
- `index.html` — content and sections
- `css/styles.css` — visual system, responsiveness, animations and print styles
- `js/app.js` — navigation, product detail modal, presentation mode, print, summary download and enquiry email draft
- `assets/` — logos and reference screenshots
- `docs/` — deployment, QA, company details register, profile gap register and internal-only commercial configuration

## Confidential owner file (outside website folder)
The ZIP includes a sibling `OWNER-PRIVATE` folder with an internal commercial configuration document. It is intentionally **outside** the `lakshya-corporate-webapp` publish folder. Do not move it into the website folder or upload it to a public repository/site. Deploy only the contents of `lakshya-corporate-webapp`.


## Added field campaign package
The public site now includes a Field Campaign Package section for campaign planning, door-to-door visits, institution visits, lead capture, follow-up, reporting and compliance. Detailed scope checklist: `docs/FIELD-CAMPAIGN-DOOR-TO-DOOR-PACKAGE.md`. Internal commercial prices and client-specific agreement accounting are intentionally excluded from the public website.
